# -*- coding: utf-8 -*-
"""
Prerequisiti:
    Scaricare ffmpeg: https://ffmpeg.org/
    Inserire la cartella di ffmpeg all'interno della cartella di lavoro python
    
@author: Filippo M - Last update 3DEC19
"""

import os # Libreria per gestione filesystem

if os.path.exists("PianoC.wav"):
  os.remove("PianoC.wav")


import subprocess as sp # Libreria d'ausilio per lanciare comandi su shell

# Conversione MP3 -> WAV con ffmpeg
# -vn skippa eventuale video
# pcm_s16le PCM signed 16-bit little-endian https://trac.ffmpeg.org/wiki/audio%20types
# -ac audio channels
# -ar audio sampling frequency
# -f format
cmdffmpeg = "./ffmpeg/bin/ffmpeg -i Piano2.mp3 -vn -acodec pcm_s16le -ac 1 -ar 44100 -f wav PianoC.wav"

print(cmdffmpeg)
sp.call(cmdffmpeg) # Esegue il comando ffmpeg



from scipy.io import wavfile # Libreria per leggere file WAVE

samplerate, data = wavfile.read("PianoC.wav") # Brano 1 (mono)
#samplerate, data = wavfile.read("InfMus.wav") # Brano 2 (stereo)
#data = data[:,0] # Prendiamo solo il canale 1 del file InfMus che e' stereo

print( "Tasso di campionamento (Samplerate): " + str(samplerate) + " Hz" )
print( "Campioni: " + str(data.shape[0]) )
print( "Durata: " + str(round(data.shape[0]/samplerate)) + " secondi" )



import matplotlib.pyplot as plt # Libreria per fare grafici

plt.figure()
plt.plot(data)
plt.xlabel("Time")
plt.ylabel("Intensity PCM 16bit")
plt.title("Initial waveform")



from scipy.fftpack import fft,fftfreq # Libreria per calcolare la FFT

datafft = fft(data) # Restituisce un numero complesso (parte reale e immaginaria)
fftabs = abs(datafft) # Calcoliamo la magnitudine = sqrt(real+imag)
freqs = fftfreq(data.shape[0],1./samplerate)

plt.figure() # Plot FFT
plt.xlim( [10, samplerate/2.] ) # Diviso 2 per freq Nyquist
#plt.xscale( 'log' )
plt.grid( True )
plt.xlabel( 'Frequency (Hz)' )
plt.ylabel("Intensity")
plt.plot(freqs[:int(freqs.size/2.)],fftabs[:int(freqs.size/2.)]) # Diviso 2 per freq Nyquist
plt.title("FFT")


plt.figure() # Plot Spettrogramma
plt.specgram(data,Fs=samplerate)
plt.xlabel('Time')
plt.ylabel('Frequency')
plt.title("Specgram")
plt.show()


from scipy.fftpack import dct
datadct = dct(data, type=2)
freqdct = freqs

#Correzione dovuta alla libreria: fra FFT e DCT c'è una differenza di *2
datadct = dct(data, type=2) /2
freqdct = freqs /2

plt.figure() # Plot DCT
plt.xlim( [10, samplerate/2.] )
#plt.xscale( 'log' )
plt.grid( True )
plt.xlabel( 'Frequency (Hz)' )
plt.ylabel("Intensity")
plt.plot(freqs[:int(freqdct.size/2.)],datadct[:int(freqs.size/2.)])
plt.title("DCT")
# Valori negativi di intensità indicano uno
# sfasamento di 180 gradi delle armoniche sinusoidali della DCT


dctabs = abs(datadct)
plt.figure() # Plot DCT
plt.xlim( [10, samplerate/2.] )
#plt.xscale( 'log' )
plt.grid( True )
plt.xlabel( 'Frequency (Hz)' )
plt.ylabel("Intensity")
plt.plot(freqdct[:int(freqs.size/2.)],dctabs[:int(freqs.size/2.)])
plt.title("abs(DCT)")



dctabs = abs(datadct)
plt.figure() # Plot DCT
plt.xlim([0,7500])
#plt.xscale( 'log' )
plt.grid( True )
plt.xlabel( 'Frequency (Hz)' )
plt.ylabel("Intensity")
plt.plot(freqs[:int(freqs.size/2.)],fftabs[:int(freqs.size/2.)])
plt.plot(freqdct[:int(freqs.size/2.)],dctabs[:int(freqs.size/2.)])
plt.title("FFT vs DCT")



### ELABORAZIONE
from scipy.fftpack import ifft
import numpy as np
segnale = ifft(datafft/4.) # Riduciamo l'intensita' (il volume)
segnale = np.int16(segnale.real)
#segnale = segnale / segnale.max() # Normalizzazione a volume 1
segnale = np.asarray(segnale, dtype=np.int16)
plt.figure()
plt.plot(data)
plt.plot(segnale)
plt.ylabel("Intensity")
plt.xlabel("Time")
plt.title("Original VS Processed waveform")
plt.show()



wavfile.write("Output.wav", samplerate, segnale)