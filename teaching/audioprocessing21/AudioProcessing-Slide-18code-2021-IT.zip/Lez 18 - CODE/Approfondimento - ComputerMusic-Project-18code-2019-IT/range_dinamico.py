"""
Estensione del docente: gli effetti di un Compressore dinamico
Il seguente codice è stato modificato rispetto alla sua versione originale
sottomessa in fase progettuale, per renderlo più spendibile a fini didattici
    
@author: Filippo M - Last update 3DEC19
"""


#Misura della variazione del range dinamico nel dominio delle frequenze

import numpy as np
from scipy.io.wavfile import read
import matplotlib.pyplot as plt


#1. Leggo il file wave

file = read("guitar_loop.wav")



#2. Trasformo il file wave in array

array = np.array(file[1], dtype=float)



#3. Il File è in stereo. Considero solo un canale lavorando in mono

signal=[]

for i in range(0, (len(array)-1)):
    signal.append(array[i][0])

plt.figure()
plt.plot(signal)
plt.title("Versione MONO della traccia 'guitar_loop.wav'")
plt.ylabel('Intensity (PCM 16 bit)')
plt.xlabel('Time')
plt.xlim([0,85000])
plt.show()



#4. Calcolo il delta di ogni finestra
# WINDOW = 4 #Dimensione della finestra
def computeDynamicRange(signal, WINDOW=4):
    range_list=[] #array finale
    i=0
    while(i<len(signal)-WINDOW): #scorro tutto l'array
        min=signal[i]
        max=signal[i]
        for j in range(0,WINDOW): #per ogni finestra, calcolo la variazione del range
    
            if(signal[i+j]<min):
                min=signal[i+j]
    
            if(signal[i+j]>max):
                max=signal[i+j]
    
        delta=abs(max-min)
        range_list.append(delta) #inserimento nell'array finale
    
        i=i+1
    return range_list


#print("Variazioni del range dinamico: ")
#print(range_list)


plt.figure()
plt.plot(computeDynamicRange(signal))
plt.title("Range Dinamico della traccia 'guitar_loop.wav'")
plt.ylabel('Difference of Intensity')
plt.xlabel('Time')
plt.xlim([0,85000])
plt.grid()
plt.show()



C1 = read("guitar_loop_Compression24dB.wav")[1]
y=computeDynamicRange(C1)
plt.figure()
plt.plot(computeDynamicRange(C1))
plt.title("Range Dinamico dopo Compressore 24dB")
plt.ylabel('Difference of Intensity')
plt.xlabel('Time')
plt.xlim([0,85000])
plt.grid()
plt.show()


C2 = read("guitar_loop_Compression48dB.wav")[1]
y=computeDynamicRange(C2)
plt.figure()
plt.plot(computeDynamicRange(C2))
plt.title("Range Dinamico dopo Compressore 48dB")
plt.ylabel('Difference of Intensity')
plt.xlabel('Time')
plt.xlim([0,85000])
plt.grid()
plt.show()


C3 = read("guitar_loop_Compression60dBrapporto10.wav")[1]
y=computeDynamicRange(C3)
plt.figure()
plt.plot(computeDynamicRange(C3))
plt.title("Range Dinamico dopo Compressore 60dB")
plt.ylabel('Difference of Intensity')
plt.xlabel('Time')
plt.xlim([0,85000])
plt.grid()
plt.show()



plt.figure()
plt.plot(computeDynamicRange(C3))
plt.plot(computeDynamicRange(C2))
plt.plot(computeDynamicRange(C1))
plt.plot(computeDynamicRange(signal))
plt.title("Confronto")
plt.ylabel('Difference of Intensity')
plt.xlabel('Time')
plt.xlim([0,85000])
plt.grid()
plt.show()